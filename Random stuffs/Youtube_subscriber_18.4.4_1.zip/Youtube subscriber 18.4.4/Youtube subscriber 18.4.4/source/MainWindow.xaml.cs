﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Youtube_subscribers
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;
        private bool contRunning;
        private bool contStopCalled;
        private CookieContainer cookies = new CookieContainer();
        private string profileDir = "profiles/";
        private string selectedProfileFile = "selectedProfile.txt";
        private string apiKeyFile = "apiKey.txt";
        private string channelID;

        private string configFile = "config.txt";
        private string[] configLines;
        private string logFile = "subscriber counts.txt";
        private string subFileTest = "subscription request test.txt";
        private string subFileReal = "subscription request real.txt";
        private string currentConfigFile;
        private string currentLogFile;
        private string currentSubFileTest;
        private string currentSubFileReal;

        private HttpWebRequest request = null;
        private byte[] data = null;
        private bool subscribeStarted = false;
        private bool subscribeFinished = false;
        private int activeThreads;
        private bool cycleRunning = false;
        private bool threadsRunning = false;

        private DispatcherTimer threadStartTimer;
        private int threadAm;
        private int startContCounter = 0;
        private int prevCount;
        private int requestCount;
        private bool targetReached;
        private bool profileChanged; //without it, subscription count of the previous profile can appear, resulting in starting of continuous mode.
        
        private bool isRealBuild = false;

        private int timeout = 5000; //default value, gets its value from config file.

        public MainWindow()
        {
            try
            {
                InitializeComponent();

                timer = new DispatcherTimer();
                timer.Tick += Timer_Tick;

                string[] profiles = Directory.GetDirectories(profileDir);
                for(int i=0; i < profiles.Length; i++)
                {
                    profiles[i] = profiles[i].Replace(profileDir, "");
                }
                ProfileList.ItemsSource = profiles;
                ProfileList.SelectedItem = File.ReadAllText(selectedProfileFile);
                //ProfileList_SelectionChanged is called now.
                currentSubFileTest = profileDir + "/" + subFileTest;
                
                BuildRequestTest_Click(null, null);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void ProfileList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                string item = ProfileList.SelectedItem.ToString();

                File.WriteAllText(selectedProfileFile, item);
                currentConfigFile = profileDir + item + "/" + configFile;
                currentLogFile = profileDir + item + "/" + logFile;
                currentSubFileReal = profileDir + item + "/" + subFileReal;
                prevCount = -1;
                profileChanged = true;
                targetReached = false;
                requestCount = 0;
                RequestCounter.Text = requestCount.ToString();
                subscribeStarted = false;
                subscribeFinished = false;

                configLines = File.ReadAllLines(currentConfigFile);
                bool autoStart = false;
                foreach (string line in configLines)
                {
                    if (line != "" && line[0] != '\'')
                    {
                        string[] arr2 = line.Split(':');
                        switch (arr2[0])
                        {
                            case "ChannelID":
                                channelID = arr2[1].Trim();
                                break;
                            case "AutoStart":

                                if (arr2[1].Trim() == "Yes")
                                {
                                    autoStart = true;
                                }
                                else
                                {
                                    autoStart = false;
                                }
                                AutoStartBox.IsChecked = autoStart;
                                break;
                            case "Timeout":
                                timeout = int.Parse(arr2[1].Trim());
                                break;
                            default:
                                TextBox el = (TextBox)this.FindName(arr2[0]);
                                el.Text = arr2[1].Trim();
                                break;
                        }
                    }
                }

                if (contRunning)
                {
                    contStopCalled = true;
                }

                if (autoStart && !timer.IsEnabled || !autoStart && timer.IsEnabled) //start or stop timer
                {
                    StartStopTimer_Click(null, null);
                    StartStopTimer.Focus();
                }
                else if (autoStart && timer.IsEnabled)
                {
                    timer.Interval = TimeSpan.FromMilliseconds(int.Parse(IntervalTime.Text));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                for(int i=0; i < configLines.Length; i++)
                {
                    string line = configLines[i];
                    if (line != "" && line[0] != '\'')
                    {
                        string[] arr2 = line.Split(':');
                        switch (arr2[0])
                        {
                            case "ChannelID":
                                break;
                            case "AutoStart":
                                arr2[1] = (bool)AutoStartBox.IsChecked ? " Yes" : " No";
                                break;
                            case "Timeout":
                                break;
                            default:
                                TextBox el = (TextBox)this.FindName(arr2[0]);
                                arr2[1] = " " + el.Text.Trim();
                                break;
                        }
                        configLines[i] = string.Join(":",arr2);
                    }
                }
                File.WriteAllLines(currentConfigFile, configLines);
                StatusText.Text += "Configuration saved." + Environment.NewLine;
                StatusText.ScrollToEnd();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void BuildRequestTest_Click(object sender, RoutedEventArgs e) //takes 52 ms.
        {
            BuildRequest(false);
        }

        private void BuildRequestReal_Click(object sender, RoutedEventArgs e) //takes 52 ms.
        {
            BuildRequest(true);
        }

        private void BuildRequest(bool real) //takes 52 ms.
        {
            try
            {
                Stopwatch stw = new Stopwatch();
                stw.Start();
                Debug.Print("BuildRequest real?" + real);
                string[] requestLines = real ? File.ReadAllLines(currentSubFileReal) : File.ReadAllLines(currentSubFileTest);
                string[] firstLine = requestLines[0].Split(' ');

                Debug.Print("File loaded " + stw.ElapsedMilliseconds);

                request = (HttpWebRequest)WebRequest.Create(firstLine[1]);
                request.Timeout = timeout;
                request.Method = "POST";

                Debug.Print("Will parse file " + stw.ElapsedMilliseconds);

                for (int i = 1; i < requestLines.Length; i++)
                {
                    if (requestLines[i].IndexOf(": ") != -1) //header
                    {
                        string[] arr = requestLines[i].Split(new string[] { ": " }, StringSplitOptions.None);
                        switch (arr[0])
                        {
                            case "Accept":
                                request.Accept = arr[1];
                                break;
                            case "Content-Type":
                                request.ContentType = arr[1];
                                break;
                            case "Referer":
                                request.Referer = arr[1];
                                break;
                            case "User-Agent":
                                request.UserAgent = arr[1];
                                break;
                            case "Connection":
                                request.KeepAlive = true;
                                break;
                            case "Host":
                                request.Host = arr[1];
                                break;
                            case "Content-Length": //it is ignored, will be calculated instead.
                                break;
                            default:
                                request.Headers.Add(arr[0], arr[1]);
                                break;
                        }
                    }
                    else //empty line or data
                    {
                        if (requestLines[i] != "") //data
                        {
                            request.ContentLength = requestLines[i].Length;
                            string postData = requestLines[i];
                            data = Encoding.ASCII.GetBytes(postData);
                            Debug.Print("data length: " + requestLines[i].Length + ", encoded length: " + data.Length);
                        }
                    }
                }

                Debug.Print("Built request in " + stw.ElapsedMilliseconds);

                StatusText.Text += real ? "Built real request in " : "Built test request in ";
                StatusText.Text += stw.ElapsedMilliseconds + " ms." + Environment.NewLine;
                StatusText.ScrollToEnd();
                isRealBuild = real;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void SubscribeButton_Click(object sender, RoutedEventArgs e)
        {
            Subscribe(0, "");
        }

        private void Subscribe(int threadNo, string sourceLine)
        {
            bool contStart = false;
            if (threadNo == -1)
            {
                contStart = true;
                threadNo = 0;
            }
            bool real = isRealBuild;
            try
            {
                if (subscribeStarted) //no real or test subscription after the one that counts.
                {
                    if (threadNo == 0)
                    {
                        StatusText.Text += "Already subscribed." + Environment.NewLine;
                        StatusText.ScrollToEnd();
                    }
                    else
                    {
                        Dispatcher.Invoke(() =>
                        {
                            StatusText.Text += "Already subscribed." + Environment.NewLine;
                            StatusText.ScrollToEnd();
                        });
                       
                    }                    
                    return;
                }
                if (real)
                {
                    subscribeStarted = true;
                }                
                Stopwatch stw = new Stopwatch();
                stw.Start();

                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }                

                var response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                stw.Stop();
                File.WriteAllText("subscription response " + DateTime.Now.ToString(@"yyyyMMdd_HHmmss.fff") + " in " + stw.ElapsedMilliseconds + ".txt", responseString);
                response.Close();
                Debug.Print("Subscribed: " + stw.ElapsedMilliseconds);
                Debug.Print(responseString);
                
                if (threadNo == 0) //button was pressed, or limit reached, and continuous is starting now.
                {
                    StatusText.Text += real ? "Real " : "Test ";
                    StatusText.Text += contStart ? "automatic " : "manual ";
                    StatusText.Text += "subscription in " + stw.ElapsedMilliseconds + " ms.";
                    StatusText.Text += Environment.NewLine;
                    StatusText.ScrollToEnd();
                }
                else //automatic real subscription at target
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text += real ? "Real" : "Test"; //real by design, unless the user built a test request after continuous started automatically.
                        StatusText.Text += " automatic subscription in " + stw.ElapsedMilliseconds + " ms.";
                        StatusText.Text += sourceLine != "" ? " Within target: " + sourceLine : "";
                        StatusText.Text += Environment.NewLine;
                        StatusText.ScrollToEnd();
                    });
                }                

                if (!real && !contStart) //for subsequent requests; we are in the main thread.
                {
                    BuildRequestTest_Click(null, null); //can it be built 5x?
                }
                else
                {
                    subscribeFinished = true;
                }                                
            }
            catch (Exception ex)
            {
                Debug.Print("Subscribe error: " + ex.Message + " " + ex.StackTrace);
                if (threadNo == 0) //timer
                {
                    StatusText.Text += "Error at Subscribe(): " + ex.Message + Environment.NewLine;
                    StatusText.ScrollToEnd();
                }
                else //continuous
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        StatusText.Text += "Error at Subscribe(): " + ex.Message + Environment.NewLine;
                        StatusText.ScrollToEnd();
                    });
                }

                if (!real) //for subsequent requests; we are in the main thread.
                {
                    BuildRequestTest_Click(null, null); //can it be built 5x?
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            GetSubscribers(0);
        }

        private void StartStopTimer_Click(object sender, RoutedEventArgs e)
        {
            if (contRunning)
            {
                contStopCalled = true;
            }
            //it is okay to start the timer, even if a request is still in progress.
            if (timer.IsEnabled)
            {
                timer.Stop();
                StartStopTimer.Content = "Start timer";
                StartStopTimer.Style = Resources["GreenButton"] as Style;
            }
            else
            {
                timer.Interval = TimeSpan.FromMilliseconds(int.Parse(IntervalTime.Text));
                timer.Start();
                StartStopTimer.Content = "Stop timer";
                StartStopTimer.Style = Resources["RedButton"] as Style;
                prevCount = -1;
            }
        }

        private void IntervalTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                timer.Interval = TimeSpan.FromMilliseconds(int.Parse(IntervalTime.Text));
            }
        }

        private void IntervalTime_GotFocus(object sender, RoutedEventArgs e)
        {
            IntervalTime.CaretIndex = IntervalTime.Text.Length;
        }

        private void Continuous_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (timer.IsEnabled)
                {
                    timer.Stop();
                    StartStopTimer.Content = "Start timer";
                    StartStopTimer.Style = Resources["GreenButton"] as Style;
                }

                if (contRunning)
                {
                    contStopCalled = true;
                }
                else
                {
                    contRunning = true;
                    Continuous.Content = "Stop continuous";
                    Continuous.Style = Resources["RedButton"] as Style;
                    prevCount = -1;

                    List<Thread> threads = new List<Thread>();

                    activeThreads = 0;
                    cycleRunning = true;
                    threadsRunning = true;
                    threadAm = int.Parse(ThreadAmount.Text) <= 5 ? int.Parse(ThreadAmount.Text) : 5;

                    //using thread.sleep in a cycle will interfere with subthreads. Timer is used instead.
                    startContCounter = 0;
                    threadStartTimer = new DispatcherTimer();
                    threadStartTimer.Interval = TimeSpan.FromMilliseconds(int.Parse(StartDelay.Text));
                    threadStartTimer.Tick += ThreadStartTimer_Tick;
                    threadStartTimer.Start();
                    ThreadStartTimer_Tick(null, null); //to start the timer immediately
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void ThreadStartTimer_Tick(object sender, EventArgs e)
        {
            startContCounter++;//first value is 1.

            if (!contStopCalled && startContCounter <= threadAm)
            {
                Thread thread = new Thread(new ThreadStart(() => StartSubscribersThread(startContCounter)));
                thread.IsBackground = true; //so threads exit on closing the program.
                thread.Start();
                activeThreads++;
                Dispatcher.Invoke(new Action(() => { }), DispatcherPriority.ContextIdle); //no effect, when calling from thread, inside or outside of this.Dispatcher.Invoke(()
            }

            if (contStopCalled || startContCounter == threadAm) //cycle was finished or interrupted
            {
                threadStartTimer.Stop();
                threadStartTimer = null;
                cycleRunning = false;
            }

            if (!threadsRunning && !cycleRunning) //stop was called before all thread could start.
            {
                contStopCalled = false;
                contRunning = false;
                Continuous.Content = "Start continuous";
                Continuous.Style = Resources["GreenButton"] as Style;
            }
        }

        private void StartSubscribersThread(int treadNo)
        {
            int limit=0;
            this.Dispatcher.Invoke(() =>
            {
                limit = int.Parse(ContAmount.Text);
            });
            if (limit != 0)
            {
                for (int i = 0; i < limit; i++)
                {
                    if (contStopCalled)
                    {
                        break;
                    }
                    GetSubscribers(treadNo);
                }
            }
            else
            {
                do
                {
                    GetSubscribers(treadNo);
                }
                while (!contStopCalled);
            }
            activeThreads--;
            if (activeThreads == 0)//all threads stopped, but maybe not all started yet. contStopCalled is used as a condition in the cycle.
            {
                threadsRunning = false;
                if (!threadsRunning && !cycleRunning)
                {
                    contStopCalled = false;
                    contRunning = false;
                    this.Dispatcher.Invoke(() =>
                    {
                        Continuous.Content = "Start continuous";
                        Continuous.Style = Resources["GreenButton"] as Style;
                    });
                }
            }            
        }

        private void RequestFull_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Stopwatch stw = new Stopwatch();
                stw.Start();
                WebRequest request = WebRequest.Create("https://www.googleapis.com/youtube/v3/channels?part=statistics&id=" + channelID + "&key=" + File.ReadAllText(apiKeyFile));
                request.Timeout = timeout;
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();
                stw.Stop();
                ResponseText1.Text += responseFromServer;
                ResponseText1.ScrollToEnd();
                reader.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void GetSubscribers(int threadNo)
        {
            try
            {
                profileChanged = false;
                requestCount++;
                Stopwatch stw = new Stopwatch();
                stw.Start();
                WebRequest request = WebRequest.Create("https://www.googleapis.com/youtube/v3/channels?part=statistics&id=" + channelID + "&key=" + File.ReadAllText(apiKeyFile));
                //Debug.Print("https://www.googleapis.com/youtube/v3/channels?part=statistics&id=" + channelID + "&key=" + File.ReadAllText(apiKeyFile));
                request.Timeout = timeout;
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                for (int j = 0; j < 15; j++)
                {
                    reader.ReadLine();
                }
                string responseFromServer = reader.ReadLine();
                string[] arr = responseFromServer.Split(':');

                int count = int.Parse(arr[1].Replace("\"","").Replace(",",""));
                int target = 0;
                int minus = 0;

                if (threadNo == 0) //timer
                {
                    target = Target.Text == "" ? 0 : int.Parse(Target.Text);
                    minus = TargetMinus.Text == "" ? 0 : int.Parse(TargetMinus.Text);
                }
                else //continuous
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        target = Target.Text == "" ? 0 : int.Parse(Target.Text);
                        minus = TargetMinus.Text == "" ? 0 : int.Parse(TargetMinus.Text);
                    });
                }

                stw.Stop();
                
                reader.Close();
                response.Close();                

                string dataLine = DateTime.Now.ToString(@"yyyy.MM.dd. HH\:mm\:ss\.fff") + " --- " + count + " --- " + stw.ElapsedMilliseconds;

                if (profileChanged) //the profile was changed during the request
                {
                    return;
                }

                if (count >= (target - minus) && count < target) //90 => 99
                {
                    if (!subscribeStarted) //no text change now, program needs to run as fast as possible
                    {
                        Subscribe(threadNo, dataLine);
                    }
                    else if (!subscribeFinished)
                    {
                        if (threadNo == 0) //timer
                        {
                            StatusText.Text += "Within target: " + count + ", no action." + Environment.NewLine;
                            StatusText.ScrollToEnd();
                        }
                        else //continuous
                        {
                            this.Dispatcher.Invoke(() =>
                            {
                                StatusText.Text += "Within target: " + count + ", no action." + Environment.NewLine;
                                StatusText.ScrollToEnd();
                            });
                        }
                    }
                }
                else if (count >= target && prevCount < target && prevCount != -1 && !targetReached) //target is reached, so we know we have to stop continuous requests later.
                    //(In contrast with the user rewriting the target, which would result in the target being less than the subscriber count.)
                {
                    targetReached = true;
                    //writing data to textbox
                    if (threadNo == 0) //timer
                    {
                        StatusText.Text += "Target reached." + Environment.NewLine;
                        StatusText.ScrollToEnd();
                    }
                    else //continuous
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            StatusText.Text += "Target reached." + Environment.NewLine;
                            StatusText.ScrollToEnd();
                        });
                    }
                }
                
                //writing data to textbox
                if (threadNo == 0) //timer
                {
                    RequestCounter.Text = requestCount.ToString();
                    ResponseText1.Text += dataLine + Environment.NewLine;
                    ResponseText1.ScrollToEnd();
                }
                else //continuous
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        RequestCounter.Text = requestCount.ToString();
                        TextBox t = (TextBox)this.FindName("ResponseText" + threadNo);
                        t.Text += dataLine + Environment.NewLine;
                        t.ScrollToEnd();
                    });                    
                }
                Dispatcher.Invoke(new Action(() => { }), DispatcherPriority.ContextIdle);

                if (profileChanged)
                {
                    return;
                }

                //starting continuous mode, if within range, or the difference has become too big. If timer is running, threadNo is 0.
                if (!contRunning && prevCount != -1 && count < target && (count >= target - int.Parse(AutoContBefore.Text) ||
                    count - prevCount > int.Parse(AutoContDiff.Text)))
                {                    
                    StatusText.ScrollToEnd();
                    BuildRequestTest_Click(null, null);
                    Subscribe(-1, "");// to keep connection alive until the real subscription.
                    BuildRequestReal_Click(null, null);

                    StatusText.Text += "Starting continuous." + Environment.NewLine;
                    Continuous_Click(null, null);
                    Continuous.Focus();
                }
                prevCount = count;

                //stopping continuous or timer after reaching target. (count >= target is necessary, because the number could have been decreased after reaching the target.)
                if (count >= target && targetReached)
                {
                    int contAfter=0;
                    int timerAfter=0;
                    if (threadNo == 0) //timer
                    {
                        contAfter = int.Parse(StopContAfter.Text);
                        timerAfter = int.Parse(StopTimerAfter.Text);
                    }
                    else
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            contAfter = int.Parse(StopContAfter.Text);
                            timerAfter = int.Parse(StopTimerAfter.Text);
                        });
                    }
                    
                    if (contRunning && contStopCalled == false) //without the last condition, this will be called as many times as many threads there are. 
                    {
                        //stop all processes.
                        if (contAfter >= timerAfter && count >= target + contAfter)
                        {
                            contStopCalled = true;
                            this.Dispatcher.Invoke(() =>
                            {
                                StatusText.Text += "Stopping continuous." + Environment.NewLine;
                                StatusText.ScrollToEnd();
                            });
                        }
                        //contAfter is meant to be less than timerAfter.
                        else if (count >= target + contAfter)
                        {
                            contStopCalled = true; //has to be set immediately to avoid multiple execution, but is also set in StartStopTimer_Click
                            this.Dispatcher.Invoke(() =>
                            {
                                StatusText.Text += "Stopping continuous and starting timer." + Environment.NewLine;
                                StatusText.ScrollToEnd();
                                StartStopTimer_Click(null, null);
                                StartStopTimer.Focus();
                            });
                        }
                    }
                    else if (!contRunning) //timer is running
                    {
                        if (count >= target + timerAfter)
                        {
                            StatusText.Text += "Stopping timer." + Environment.NewLine;
                            StatusText.ScrollToEnd();
                            StartStopTimer_Click(null, null);
                            StartStopTimer.Focus();
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                Debug.Print("GetSubscribers error: " + ex.Message + " " + ex.StackTrace);
                if (threadNo == 0) //timer
                {
                    StatusText.Text += "Error at Getsubscribers(): " + ex.Message + Environment.NewLine;
                    StatusText.ScrollToEnd();
                }
                else //continuous
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        StatusText.Text += "Error at Getsubscribers(): " + ex.Message + Environment.NewLine;
                        StatusText.ScrollToEnd();
                    });
                }
            }
        }

        private void ThreadAmount_GotFocus(object sender, RoutedEventArgs e)
        {
            ThreadAmount.CaretIndex = ThreadAmount.Text.Length;
        }

        private void StartDelay_GotFocus(object sender, RoutedEventArgs e)
        {
            StartDelay.CaretIndex = StartDelay.Text.Length;
        }

        private void ContAmount_GotFocus(object sender, RoutedEventArgs e)
        {
            ContAmount.CaretIndex = ContAmount.Text.Length;
        }

        private void AutoContBefore_GotFocus(object sender, RoutedEventArgs e)
        {
            AutoContBefore.CaretIndex = AutoContBefore.Text.Length;
        }

        private void AutoContDiff_GotFocus(object sender, RoutedEventArgs e)
        {
            AutoContDiff.CaretIndex = AutoContDiff.Text.Length;
        }

        private void ClearText_Click(object sender, RoutedEventArgs e)
        {
            ResponseText1.Text = "";
            ResponseText2.Text = "";
            ResponseText3.Text = "";
            ResponseText4.Text = "";
            ResponseText5.Text = "";
        }

        private void GetEstimate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string[] arr = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + currentLogFile);
                string firstLine = arr[0];
                string lastLine = arr[arr.Length - 1]; //file has to have a new line at the end, but this empty line is not present in the array.

                int target = int.Parse(Target.Text);
                if (requestCount != 0 && ResponseText1.Text != "") //the text could have been cleared, which didn't reset the request counter.
                {
                    try
                    {
                        string[] responseArr = ResponseText1.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                        string currentLast = responseArr[responseArr.Length - 1];
                        Debug.Print("Estimate, current last: " + currentLast);
                        string[] arr2 = currentLast.Split(new string[] { " --- " }, StringSplitOptions.None);
                        DateTime currentTime = DateTime.ParseExact(arr2[0], @"yyyy.MM.dd. HH\:mm\:ss\.fff", CultureInfo.InvariantCulture);
                        int currentNo = int.Parse(arr2[1]);
                        int currentLeft = target - currentNo;

                        arr2 = firstLine.Split(new string[] { " --- " }, StringSplitOptions.None); //or Regex.Split(input, @"\]\[");            
                        DateTime firstTime = DateTime.ParseExact(arr2[0], @"yyyy.MM.dd. HH\:mm\:ss\.fff", CultureInfo.InvariantCulture);
                        int firstNo = int.Parse(arr2[1]);
                        int firstLeft = target - firstNo;

                        arr2 = lastLine.Split(new string[] { " --- " }, StringSplitOptions.None); //or Regex.Split(input, @"\]\[");            
                        DateTime lastTime = DateTime.ParseExact(arr2[0], @"yyyy.MM.dd. HH\:mm\:ss\.fff", CultureInfo.InvariantCulture);
                        int lastNo = int.Parse(arr2[1]);
                        int lastLeft = target - lastNo;

                        //2018.07.30. 00:00:00.507 --- 6527055 --- 134
                        //2018.07.30. 10:14:17.519 --- 6573583 --- 467

                        //firstLeft: 480000
                        //currentleft: 430000
                        //firstNoDiff: 50000

                        TimeSpan firstTimeDiff = currentTime.Subtract(firstTime);
                        TimeSpan lastTimeDiff = currentTime.Subtract(lastTime);
                        int firstNoDiff = firstLeft - currentLeft;
                        int lastNoDiff = lastLeft - currentLeft;

                        if (firstNoDiff == 0)
                        {
                            MessageBox.Show("Current subscriber count is the same as in the first line of the log. Estimation is not possible.");
                        }
                        else if (lastNoDiff == 0)
                        {
                            MessageBox.Show("Current subscriber count is the same as in the last line of the log. Estimation is not possible.");
                        }
                        else
                        {
                            //Debug.Print("firstLeft " + firstLeft + " lastLeft " + lastLeft + " firstNoDiff " + firstNoDiff
                            //    + " lastNoDiff " + lastNoDiff + " currentLeft " + currentLeft + " firstTimeDiff " + firstTimeDiff + " lastTimeDiff " + lastTimeDiff);
                            //Debug.Print("firstTimeDiff.TotalMilliseconds " + firstTimeDiff.TotalMilliseconds + " lastTimeDiff.TotalMilliseconds " + lastTimeDiff.TotalMilliseconds);
                            TimeSpan firstRemaining = TimeSpan.FromMilliseconds((double)currentLeft / (double)firstNoDiff * firstTimeDiff.TotalMilliseconds); //without casting to double, we may get 0 as result.
                                                                                                                                                              //Debug.Print("frommillisec " + (double)currentLeft / (double)firstNoDiff * firstTimeDiff.TotalMilliseconds);
                            TimeSpan lastRemaining = TimeSpan.FromMilliseconds((double)currentLeft / (double)lastNoDiff * lastTimeDiff.TotalMilliseconds);

                            //Debug.Print("firstRemaining " + firstRemaining + " lastRemaining " + lastRemaining);
                            DateTime firstEstimate = currentTime.Add(firstRemaining);
                            DateTime lastEstimate = currentTime.Add(lastRemaining);

                            FirstEstimate.Text = firstEstimate.ToString(@"yyyy.MM.dd. HH\:mm\:ss\.fff");
                            LastEstimate.Text = lastEstimate.ToString(@"yyyy.MM.dd. HH\:mm\:ss\.fff");
                        }                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
                    }
                }
                else
                {
                    MessageBox.Show("Get current information.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        private void SaveLastLine_Click(object sender, RoutedEventArgs e)
        {
            if (ResponseText1.Text != "")
            {
                string[] responseArr = ResponseText1.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                string currentLast = responseArr[responseArr.Length - 1];
                File.AppendAllLines(AppDomain.CurrentDomain.BaseDirectory + currentLogFile, new string[] { currentLast });
                StatusText.Text += "Line saved." + Environment.NewLine;
                StatusText.ScrollToEnd();
            }
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            //text boxes should not be written letters into
            switch (e.Key)
            {
                case Key.T:
                    StartStopTimer_Click(null, null);
                    StartStopTimer.Focus();
                    e.Handled = true;
                    break;
                case Key.C:
                    if (!Keyboard.IsKeyDown(Key.LeftCtrl) && !Keyboard.IsKeyDown(Key.RightCtrl)) //to avoid accidental mix-ups of keys
                    {
                        Continuous_Click(null, null);
                        Continuous.Focus();
                        e.Handled = true;                        
                    }
                    break;
                case Key.B:
                    BuildRequestTest_Click(null, null);
                    BuildRequestTest.Focus();
                    e.Handled = true;
                    break;
                case Key.N:
                    BuildRequestReal_Click(null, null);
                    BuildRequestReal.Focus();
                    e.Handled = true;
                    break;
                case Key.S:
                    if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) //to avoid accidental mix-ups of keys
                    {
                        SaveConfig_Click(null, null);
                        SaveConfig.Focus();
                        e.Handled = true;                        
                    }
                    break;
                case Key.Escape: //stops all running operations
                    if (timer.IsEnabled)
                    {
                        timer.Stop();
                        StartStopTimer.Content = "Start timer";
                        StartStopTimer.Style = Resources["GreenButton"] as Style;
                    }

                    if (contRunning)
                    {
                        contStopCalled = true;
                    }
                    break;
                case Key.L:
                    SaveLastLine_Click(null, null);
                    SaveLastLine.Focus();
                    e.Handled = true;
                    break;
                case Key.E:
                    GetEstimate_Click(null, null);
                    GetEstimate.Focus();
                    e.Handled = true;
                    break;
                case Key.U:
                    SubscribeButton_Click(null, null);
                    SubscribeButton.Focus();
                    e.Handled = true;
                    break;
            }            
        }
    }
}
